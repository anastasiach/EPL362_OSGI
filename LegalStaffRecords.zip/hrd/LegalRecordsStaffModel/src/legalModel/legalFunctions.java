package legalModel;

import java.sql.ResultSet;

public interface legalFunctions {

	boolean addPatient(int id, String name, String Address, int level,
			String realative, int hurm, int dead);

	boolean addStaff(int id, String name, String Address, String branch,String username,
			String password,int law, int secretary, int receptionist, int health, int manager);

	ResultSet getClients();

	ResultSet getStaff();

	ResultSet getInfoForClient(int id);

	ResultSet getInfoForStaff(int id);

	boolean editClient(int id, String name, String Address, int level,
			String realative, int hurm, int dead);

	boolean editStaff(int id, String name, String Address, String branch,String username,
			String password,int law, int secretary, int receptionist, int health, int manager);

	boolean checkString(String t);

	boolean checkNumber(String s);

	boolean checkEmailAddress(String s);

	boolean SendEmailtoALL(int p_id, String remail, String Name);

}
