package legalFactory;

import legalModel.legalFunctions;
import legalService.legalFunctionsImpl;

public class legalServiceFactory {
	
	private static legalFunctions legalService = new legalFunctionsImpl();

	  public static legalFunctions getFactory() {
	    return legalService;
	  }
}
