package legal;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.Color;

import javax.swing.border.TitledBorder;
import javax.swing.border.LineBorder;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.JButton;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class General extends JFrame {

	private JPanel contentPane;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					General frame = new General(1);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public General(int ID) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 407, 349);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setForeground(Color.BLACK);
		panel.setBorder(new TitledBorder(new LineBorder(new Color(0, 0, 128), 3), "Clients  Information", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel.setBackground(Color.WHITE);
		contentPane.add(panel, BorderLayout.CENTER);
		
		JPanel panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBorder(new LineBorder(new Color(0, 0, 128)));
		panel_1.setBackground(new Color(173, 216, 230));
		panel_1.setBounds(10, 32, 361, 259);
		panel.add(panel_1);
		
		JButton btnInsertClients = new JButton("Insert Clients");
		btnInsertClients.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {				
				GUI_Clients frame = new GUI_Clients(ID);
				frame.setVisible(true);
				setVisible(false);

			}
		});
		btnInsertClients.setFont(new Font("Calibri", Font.PLAIN, 14));
		btnInsertClients.setBounds(34, 75, 126, 23);
		panel_1.add(btnInsertClients);
		
		JLabel lblInsertClientsOr = new JLabel("Insert Clients OR Staff :");
		lblInsertClientsOr.setFont(new Font("Calibri", Font.PLAIN, 14));
		lblInsertClientsOr.setBounds(34, 36, 233, 16);
		panel_1.add(lblInsertClientsOr);
		
		JButton btnInsertStaff = new JButton("Insert Staff");
		btnInsertStaff.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				GUI_Staff frame = new GUI_Staff(ID);
				frame.setVisible(true);
				setVisible(false);
				
			}
		});
		btnInsertStaff.setFont(new Font("Calibri", Font.PLAIN, 14));
		btnInsertStaff.setBounds(188, 75, 126, 23);
		panel_1.add(btnInsertStaff);
		
		JLabel lblEditClienttsOr = new JLabel("Edit Clients OR Staff :");
		lblEditClienttsOr.setFont(new Font("Calibri", Font.PLAIN, 14));
		lblEditClienttsOr.setBounds(34, 139, 233, 16);
		panel_1.add(lblEditClienttsOr);
		
		JButton btnEditClients = new JButton("Edit Clients");
		btnEditClients.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				Client_list frame = new Client_list(ID);
				frame.setVisible(true);
				setVisible(false);
				
			}
		});
		btnEditClients.setFont(new Font("Calibri", Font.PLAIN, 14));
		btnEditClients.setBounds(34, 173, 126, 23);
		panel_1.add(btnEditClients);
		
		JButton btnEditStaff = new JButton("Edit Staff");
		btnEditStaff.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Staff_list frame = new Staff_list(ID);
				frame.setVisible(true);
				setVisible(false);
				
			}
		});
		btnEditStaff.setFont(new Font("Calibri", Font.PLAIN, 14));
		btnEditStaff.setBounds(188, 173, 126, 23);
		panel_1.add(btnEditStaff);
	}
}
