package loginModel;

public interface loginFunction {
	
	int[] login(String username, String password);
	

}
