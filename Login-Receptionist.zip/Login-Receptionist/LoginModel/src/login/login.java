package login;

public interface login {
	
	int login(String username, String password);
	

}
