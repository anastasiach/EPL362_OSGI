package secretary;

public class clientRecord {

}
