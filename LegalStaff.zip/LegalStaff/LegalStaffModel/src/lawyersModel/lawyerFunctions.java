package lawyersModel;

import java.sql.ResultSet;

public interface lawyerFunctions {

	ResultSet getRandevous(int lawyer_id);

	ResultSet getRandevouInfo(int randevou_id);

	String[] getLastConditionAndMedicationOfPatient(int client_id);

	ResultSet getDrugs();

	boolean updateRandevou(int randevou_id, String Condition, int Medication,
			String comments, int overule, int lm, int dead, int sh,
			int client_id);

	ResultSet getNotUpdatedRandevous(int client_id);

	boolean insertIncentend(int client_id, String details, int medication);

	String checkForAllergies(int p, int m);

	String[] getDrugInfo(int dr_id);

	boolean updateDropIn(int randevou, int d_id);

	boolean SendEmailtoALL(int c_id, String remail, String Name);

}
