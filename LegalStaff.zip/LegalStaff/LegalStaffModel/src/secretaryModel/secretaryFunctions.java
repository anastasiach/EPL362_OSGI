package secretaryModel;

import java.sql.ResultSet;

public interface secretaryFunctions {

	ResultSet getClients();
	ResultSet getInfoForClient(int id);
	ResultSet getDrugs();
	String[] getLastConditionAndMedicationOfClient(int Client_id);
}
