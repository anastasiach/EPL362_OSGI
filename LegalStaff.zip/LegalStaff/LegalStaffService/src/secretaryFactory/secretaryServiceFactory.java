package secretaryFactory;

import secretaryModel.secretaryFunctions;
import secretaryService.secretaryFuctionImpl;


public class secretaryServiceFactory {
	private static secretaryFunctions secretaryService = new secretaryFuctionImpl();

	public static  secretaryFunctions getFactory() {
	    return secretaryService;
	  }
}
