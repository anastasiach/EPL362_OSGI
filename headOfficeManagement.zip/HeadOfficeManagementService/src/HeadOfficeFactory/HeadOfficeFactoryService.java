package HeadOfficeFactory;

import HeadOfficeManagement.HeadOfficeFunctions;
import HeadOfficeService.headServiceImpl;



public class HeadOfficeFactoryService {

	private static HeadOfficeFunctions healthService = new headServiceImpl();

	public static HeadOfficeFunctions getFactory() {
	    return healthService;
	  }
}
