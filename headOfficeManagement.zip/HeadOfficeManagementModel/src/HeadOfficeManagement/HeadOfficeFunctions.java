package HeadOfficeManagement;

import java.sql.ResultSet;

public interface HeadOfficeFunctions {
	
	ResultSet getClinics();
	String [][] getWeeklyReport(String branch);

}
